// src/router/index.js (or src/router/index.ts)
import { createRouter, createWebHistory } from 'vue-router'
import ClinicalNoteEditor from '../views/clinical-notes/ClinicalNoteEditor.vue'
import ClinicalNoteList from '../views/clinical-notes/ClinicalNoteList.vue'
import TreatmentPlanEditor from '../views/treatment-plans/TreatmentPlanEditor.vue'
import TreatmentPlanList from '../views/treatment-plans/TreatmentPlanList.vue'
import MessagesView from '../views/messages/MessagesView.vue'

const routes = [
    {
        path: '/login',
        name: 'Login',
        component: () => import('../views/LoginView.vue'),
        meta: { requiresAuth: false }
    },
    {
        path: '/register',
        name: 'Register',
        component: () => import('../views/RegisterView.vue'),
        meta: { requiresAuth: false }
    },
    {
        path: '/',
        component: () => import('../layout/MainLayout.vue'),
        meta: { requiresAuth: true },
        children: [
            { path: '', redirect: '/dashboard' },

            // Role-specific dashboards
            {
                path: 'dashboard',
                name: 'Dashboard',
                component: () => import('../views/DashboardView.vue'),
                meta: { title: 'Dashboard' }
            },
            {
                path: 'admin-dashboard',
                name: 'AdminDashboard',
                component: () => import('../views/dashboards/AdminDashboard.vue'),
                meta: { title: 'Admin Dashboard', roles: ['ADMIN'] }
            },
            {
                path: 'doctor-dashboard',
                name: 'DoctorDashboard',
                component: () => import('../views/dashboards/DoctorDashboard.vue'),
                meta: { title: 'Doctor Dashboard', roles: ['DOCTOR'] }
            },
            {
                path: 'nurse-dashboard',
                name: 'NurseDashboard',
                component: () => import('../views/dashboards/NurseDashboard.vue'),
                meta: { title: 'Nurse Dashboard', roles: ['NURSE', 'TECHNICIAN'] }
            },
            {
                path: 'patient-dashboard',
                name: 'PatientDashboard',
                component: () => import('../views/dashboards/PatientDashboard.vue'),
                meta: { title: 'My Health', roles: ['PATIENT'] }
            },

            // ADMIN ONLY routes
            {
                path: 'admin/users',
                name: 'UserManagement',
                component: () => import('../views/admin/UserManagementView.vue'),
                meta: { title: 'User Management', roles: ['ADMIN'] }
            },
            {
                path: 'admin/system',
                name: 'SystemMonitoring',
                component: () => import('../views/admin/SystemMonitoringView.vue'),
                meta: { title: 'System Monitoring', roles: ['ADMIN'] }
            },
            {
                path: 'audit',
                name: 'AuditLogs',
                component: () => import('../views/AuditLogView.vue'),
                meta: { title: 'Audit Logs', roles: ['ADMIN'] }
            },

            // DOCTOR routes (also accessible by ADMIN for oversight)
            {
                path: 'worklist',
                name: 'Worklist',
                component: () => import('../views/doctor/WorklistView.vue'),
                meta: { title: 'Worklist', roles: ['DOCTOR'] }
            },
            {
                path: 'reports',
                name: 'Reports',
                component: () => import('../views/ReportListView.vue'),
                meta: { title: 'Reports', roles: ['DOCTOR', 'RESEARCHER'] }
            },
            {
                path: 'reports/new/:studyId?',
                name: 'NewReport',
                component: () => import('../views/ReportEditorView.vue'),
                meta: { title: 'New Report', roles: ['DOCTOR'] }
            },
            {
                path: 'reports/:id/edit',
                name: 'EditReport',
                component: () => import('../views/ReportEditorView.vue'),
                meta: { title: 'Edit Report', roles: ['DOCTOR'] }
            },
            {
                path: 'my-patients',
                name: 'MyPatients',
                component: () => import('../views/doctor/MyPatientsView.vue'),
                meta: { title: 'My Patients', roles: ['DOCTOR'] }
            },
            {
                path: 'patients/:id',
                name: 'PatientDetail',
                component: () => import('../views/doctor/PatientDetailView.vue'),
                meta: { title: 'Patient Detail', roles: ['DOCTOR'] }
            },

            // MESSAGES ROUTE - UPDATED to include PATIENT
            {
                path: 'messages',
                name: 'Messages',
                component: MessagesView,
                meta: {
                    title: 'Messages',
                    requiresAuth: true,
                    roles: ['DOCTOR', 'ADMIN', 'PATIENT']  // ✅ Nurses removed (already not here)
                }
            },

            // NURSE/TECHNICIAN routes
            {
                path: 'upload',
                name: 'Upload',
                component: () => import('../views/UploadView.vue'),
                meta: { title: 'Upload Images', roles: ['DOCTOR', 'NURSE', 'TECHNICIAN'] }
            },
            {
                path: 'nurse/schedule',
                name: 'NurseSchedule',
                component: () => import('../views/nurse/ScheduleView.vue'),
                meta: { title: 'Today\'s Schedule', roles: ['NURSE', 'TECHNICIAN'] }
            },

            // SHARED routes (multiple roles)
            {
                path: 'studies',
                name: 'Studies',
                component: () => import('../views/StudyListView.vue'),
                meta: { title: 'Studies', roles: ['DOCTOR', 'NURSE', 'TECHNICIAN', 'RESEARCHER'] }
            },
            {
                path: 'studies/:id',
                name: 'StudyDetail',
                component: () => import('../views/StudyDetailView.vue'),
                meta: { title: 'Study Detail', roles: ['DOCTOR', 'NURSE', 'TECHNICIAN', 'RESEARCHER'] }
            },
            {
                path: 'viewer/:id',
                name: 'ImageViewer',
                component: () => import('../views/ImageViewerView.vue'),
                meta: { title: 'Image Viewer', roles: ['DOCTOR', 'RESEARCHER'] }
            },
            {
                path: 'appointments',
                name: 'Appointments',
                component: () => import('../views/doctor/AppointmentsView.vue'),
                meta: { title: 'Appointments', roles: ['DOCTOR', 'NURSE'] }
            },
            {
                path: 'pacs',
                name: 'PACS',
                component: () => import('../views/PacsView.vue'),
                meta: { title: 'PACS', roles: ['ADMIN', 'DOCTOR'] }
            },

            // PATIENT ONLY routes
            {
                path: 'my-health',
                name: 'MyHealth',
                component: () => import('../views/patient/HealthOverviewView.vue'),
                meta: { title: 'My Health', roles: ['PATIENT'] }
            },
            {
                path: 'my-appointments',
                name: 'MyAppointments',
                component: () => import('../views/patient/MyAppointmentsView.vue'),
                meta: { title: 'My Appointments', roles: ['PATIENT'] }
            },
            {
                path: 'my-reports',
                name: 'MyReports',
                component: () => import('../views/patient/MyReportsView.vue'),
                meta: { title: 'My Reports', roles: ['PATIENT'] }
            },
            {
                path: 'my-prescriptions',
                name: 'MyPrescriptions',
                component: () => import('../views/patient/PrescriptionListView.vue'),
                meta: { title: 'My Prescriptions', roles: ['PATIENT'] }
            },
            {
                path: 'my-messages',
                name: 'MyMessages',
                component: MessagesView,
                meta: { title: 'My Messages', roles: ['PATIENT'] }
            },
            // Clinical Notes
            {
                path: '/clinical-notes',
                name: 'ClinicalNotes',
                component: ClinicalNoteList,
                meta: { title: 'Clinical Notes', requiresAuth: true, roles: ['DOCTOR', 'ADMIN'] }
            },
            {
                path: '/clinical-notes/new',
                name: 'NewClinicalNote',
                component: ClinicalNoteEditor,
                meta: { title: 'New Clinical Note', requiresAuth: true, roles: ['DOCTOR'] }
            },
            {
                path: '/clinical-notes/:id/edit',
                name: 'EditClinicalNote',
                component: ClinicalNoteEditor,
                props: route => ({ noteId: parseInt(route.params.id) }),
                meta: { title: 'Edit Clinical Note', requiresAuth: true, roles: ['DOCTOR'] }
            },
            // Treatment Plans
            {
                path: '/treatment-plans',
                name: 'TreatmentPlans',
                component: TreatmentPlanList,
                meta: {
                    title: 'Treatment Plans',
                    requiresAuth: true,
                    roles: ['DOCTOR', 'ADMIN']
                }
            },
            {
                path: '/treatment-plans/new',
                name: 'NewTreatmentPlan',
                component: TreatmentPlanEditor,
                meta: {
                    title: 'New Treatment Plan',
                    requiresAuth: true,
                    roles: ['DOCTOR']
                }
            },
            {
                path: '/treatment-plans/:id/edit',
                name: 'EditTreatmentPlan',
                component: TreatmentPlanEditor,
                props: route => ({
                    planId: parseInt(route.params.id)
                }),
                meta: {
                    title: 'Edit Treatment Plan',
                    requiresAuth: true,
                    roles: ['DOCTOR']
                }
            }
        ]
    },
    { path: '/:pathMatch(.*)*', redirect: '/dashboard' }
]

const router = createRouter({
    history: createWebHistory(),
    routes
})

// Navigation guard
router.beforeEach((to, from, next) => {
    const token = localStorage.getItem('accessToken')
    const user = JSON.parse(localStorage.getItem('user') || '{}')
    const userRole = user.role || ''

    // Public routes
    if (to.meta.requiresAuth === false) {
        if (token && (to.path === '/login' || to.path === '/register')) {
            next(getDashboardForRole(userRole))
            return
        }
        next()
        return
    }

    // Check authentication
    if (!token) {
        next('/login')
        return
    }

    // Redirect /dashboard to role-specific dashboard
    if (to.path === '/dashboard') {
        next(getDashboardForRole(userRole))
        return
    }

    // Check role-based access
    if (to.meta.roles && to.meta.roles.length > 0) {
        if (!to.meta.roles.includes(userRole)) {
            next(getDashboardForRole(userRole))
            return
        }
    }

    next()
})

function getDashboardForRole(role) {
    const dashboards = {
        ADMIN: '/admin-dashboard',
        DOCTOR: '/doctor-dashboard',
        NURSE: '/nurse-dashboard',
        TECHNICIAN: '/nurse-dashboard',
        RESEARCHER: '/studies',
        PATIENT: '/patient-dashboard'
    }
    return dashboards[role] || '/login'
}

export default router